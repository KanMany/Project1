var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(400,400);
  banana=createSprite(305,290);
  banana.addImage("ba",bananaImage);
  banana.scale=0.1;
  banana.velocityX=-2;
  obstacle=createSprite(300,370);
  obstacle.addImage("ob",obstacleImage);
  obstacle.scale=0.3;
  obstacle.velocityX=-2;
  FoodGroup=createGroup();
  FoodGroup.add(banana);
  obstacleGroup=createGroup();
  obstacleGroup.add(obstacle)
  monkey= createSprite(100,360,10,10);
  monkey.addAnimation("running",monkey_running);
  monkey.scale=0.12
  background.velocityY=-2;
  
}


function draw() {
  background("cyan");
  if(background.y==100){
    background.y=400;
  }
  spawnobstacles();
  spawnbanana();
  drawSprites();
}

function spawnobstacles(){
  if(frameRate%300==0){
    obstacle=createSprite(360,380);
    obstacle.addImage("obstacle.png")
    obstacle.velocityY=2;
    obstacle.lifeTime(300);
    obstacle.scale=0.1;
  }
}
function spawnbanana(){
  if(frameCount%200==0){
    banana=createSprite(300,300);
    banana.addImage("banana",bananaImage);
    banana.velocityY=2;  
    banana.frameRate(300);
    banana.scale=0.01;
  }
}




